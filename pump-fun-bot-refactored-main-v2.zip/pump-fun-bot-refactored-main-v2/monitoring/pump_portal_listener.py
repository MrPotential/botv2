"""
Listener for PumpPortal real-time token creation events.
Uses the official pump.fun WebSocket API at wss://pumpportal.fun/api/data
"""

import asyncio
import json
import logging
import websockets
from solders.pubkey import Pubkey

from monitoring.base_listener import BaseTokenListener
from trading.base import TokenInfo

logger = logging.getLogger(__name__)

class PumpPortalListener(BaseTokenListener):
    """Listener implementation for PumpPortal's WebSocket API."""
    
    def __init__(self):
        """Initialize the PumpPortal listener."""
        self.url = "wss://pumpportal.fun/api/data"
        self.active = False
        self.websocket = None
        logger.info(f"PumpPortal listener initialized with endpoint: {self.url}")
    
    async def listen_for_tokens(self, callback, match_string=None, creator_filter=None):
        """Listen for new token creation events on PumpPortal.
        
        Args:
            callback: Function to call when a new token is detected
            match_string: Optional string to filter tokens by name/symbol
            creator_filter: Optional address to filter tokens by creator
        """
        self.active = True
        logger.info(f"Starting PumpPortal listener (filter: {match_string or 'None'})")
        
        while self.active:
            try:
                async with websockets.connect(self.url) as self.websocket:
                    logger.info("Connected to PumpPortal WebSocket")
                    
                    # Subscribe to new token events using the correct method
                    subscribe_msg = {
                        "method": "subscribeNewToken"
                    }
                    await self.websocket.send(json.dumps(subscribe_msg))
                    logger.info("Subscribed to new token events")
                    
                    # Process incoming messages
                    async for message in self.websocket:
                        if not self.active:
                            break
                            
                        try:
                            data = json.loads(message)
                            await self._process_token_message(data, callback, match_string, creator_filter)
                        except json.JSONDecodeError:
                            logger.error("Failed to decode message from PumpPortal")
                        except Exception as e:
                            logger.error(f"Error processing message: {e!s}")
                            
            except websockets.exceptions.ConnectionClosed:
                logger.warning("PumpPortal WebSocket connection closed")
            except Exception as e:
                logger.error(f"PumpPortal WebSocket error: {e!s}")
                
            if self.active:
                logger.info("Reconnecting to PumpPortal in 5 seconds...")
                await asyncio.sleep(5)
    
    async def _process_token_message(self, data, callback, match_string, creator_filter):
        """Process a token message from the WebSocket.
        
        Args:
            data: Message data from WebSocket
            callback: Function to call with token info
            match_string: Optional string filter
            creator_filter: Optional creator address filter
        """
        # Handle new token events
        if data.get("type") == "token_create":
            token_data = data.get("data", {})
            
            mint_address = token_data.get("mint")
            if not mint_address:
                logger.warning("Received token_create event without mint address")
                return
                
            name = token_data.get("name", "")
            symbol = token_data.get("symbol", "")
            
            # Apply string filter if configured
            if match_string and not (
                match_string.lower() in name.lower() or
                match_string.lower() in symbol.lower()
            ):
                logger.debug(f"Token {symbol} doesn't match filter '{match_string}', skipping")
                return
                
            # Apply creator filter if configured
            creator = token_data.get("creator", "")
            if creator_filter and creator != creator_filter:
                logger.debug(f"Token {symbol} creator doesn't match filter, skipping")
                return
                
            # Create token info object
            try:
                token_info = TokenInfo(
                    mint=Pubkey.from_string(mint_address),
                    name=name,
                    symbol=symbol,
                    creator=creator if creator else None,
                    decimals=token_data.get("decimals", 9)
                )
                
                logger.info(f"New token detected from PumpPortal: {symbol} ({mint_address})")
                await callback(token_info)
            except Exception as e:
                logger.error(f"Error creating TokenInfo: {e!s}")
    
    def stop(self):
        """Stop the listener."""
        logger.info("Stopping PumpPortal listener")
        self.active = False
